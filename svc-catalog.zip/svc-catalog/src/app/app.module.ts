import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule } from '@angular/router';
import {MatTableModule} from '@angular/material/table';
import {CdkTableModule} from '@angular/cdk/table';
import { AppComponent } from './app.component';
import { NavMenuComponent } from './nav-menu/nav-menu.component';
import { HomeComponent } from './home/home.component';
import { CounterComponent } from './counter/counter.component';
import { FetchDataComponent } from './fetch-data/fetch-data.component';
import { GridComponent } from './grid/grid.component';
import {MatFormFieldModule, MatPaginatorModule, MatSelectModule, MatInputModule,  MatSortModule, MatPaginatorIntl  } from '@angular/material';
import {MatIconModule} from '@angular/material/icon';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { CommonService } from './services/common.service'; 
import { InventoryService } from './inventory.service';
import { DetailsComponent } from './details/details.component';

 


@NgModule({
  declarations: [
    AppComponent,
    NavMenuComponent,
    HomeComponent,
    CounterComponent,
    FetchDataComponent,
    GridComponent,
    DetailsComponent
  ],
  imports: [
    BrowserModule.withServerTransition({ appId: 'ng-cli-universal' }),
    HttpClientModule,
    FormsModule,
    MatTableModule,    
    CdkTableModule,
    MatFormFieldModule,
    MatPaginatorModule,
    BrowserAnimationsModule,
    MatSelectModule,
    MatInputModule,
    MatSortModule,
    MatIconModule,
    RouterModule.forRoot([
      { path: '', component: GridComponent, pathMatch: 'full' },
      { path: 'counter', component: CounterComponent },
      { path: 'fetch-data', component: FetchDataComponent },
      { path: 'grid', component: GridComponent }
    ])
  ],
  providers: [CommonService, InventoryService,MatPaginatorIntl ],
  bootstrap: [AppComponent],
})
export class AppModule { }
