import { Subject } from 'rxjs';

export class CommonService {
    users = [
        // tslint:disable-next-line: max-line-length
        { Cluster: 'dev-cluster', ProjectTeam: 'Middleware', Namespace: 'dg-dev', ServiceName: 'dg-voice', URL: 'https://ms-dev.windstream.com/dg/dg-voice', SwaggerDescription: 'Enabled	Gets voice data for dynamic IP provisioining' },
        // tslint:disable-next-line: max-line-length
        { Cluster: 'prod-cluster', ProjectTeam: 'Front-End', Namespace: 'dg-dev', ServiceName: 'dg-voice', URL: 'https://ms-dev.windstream.com/dg/dg-voice', SwaggerDescription: 'Enabled	Gets voice data for dynamic IP provisioining' }
    ];

    data = new Subject();

    constructor() {}

    fetchData() {
        return this.users;
    }


}
