import { Project } from './Project';

export class ProjectsResponse {
	projects: Project[];
}
