import { Cluster } from './Cluster';

export class ClustersReponse {
	clusters: Array<Cluster>;
}
