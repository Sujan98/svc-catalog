export class Labels {
	swagger: boolean;
}
