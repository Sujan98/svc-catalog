import { NameSpace } from './NameSpace';

export class Project {
	id: string;
	name: string;
	namespaces: NameSpace[];
}
