
export class MicroServiceInfo {    
    project: string;
    namespace: string;
    servicename: string;
    url: string;
    swagger: string;
    description: string;
}
