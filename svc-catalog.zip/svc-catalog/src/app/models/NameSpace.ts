import { Ingress } from './Ingress';

export class NameSpace {
	name: string;
	projectId: string;
	ingresses: Ingress[];
}
