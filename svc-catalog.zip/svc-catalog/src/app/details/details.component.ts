import { Component, OnInit } from '@angular/core';
import { InventoryService } from '../inventory.service';

@Component({
  selector: 'app-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.css']
})
export class DetailsComponent implements OnInit {
  objectKeys= Object.keys;
  details = this.IntServ.details;


  constructor(private IntServ: InventoryService) { }

  ngOnInit() {
    console.log(this.objectKeys(this.details));    
  }

  close() {
    this.IntServ.closeDetails.emit();
  }

}
