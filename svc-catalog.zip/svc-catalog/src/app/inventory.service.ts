import { Injectable, OnInit, EventEmitter, Output } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ClustersReponse } from './models/ClustersResponse';
import { Cluster } from './models/Cluster';
import { Observable } from 'rxjs';
import { ProjectsResponse } from './models/ProjectsResponse';

@Injectable({
  providedIn: 'root'
})
export class InventoryService {
  isDetails = false;
  details : Object;
  @Output() closeDetails = new EventEmitter<void>();
  @Output() openDetails = new EventEmitter<void>();

  GetClusters(): Observable<ClustersReponse> {
    return this.client.get<ClustersReponse>('https://ms-dev.windstream.com/tools-dev/svc-catalog/k8s/clusters');
  }

  GetProjectss(clusterId: string): Observable<ProjectsResponse> {
    return this.client.get<ProjectsResponse>(`https://ms-dev.windstream.com/tools-dev/svc-catalog/k8s/projects/${clusterId}`);
  }

  GetDetails(): Observable<any> {
    return this.client.get<any>('https://ms-dev.windstream.com/playground-dev/svc-catalog/deploymentDetails?clusterId=c-zlzc6&namespace=playground-dev&projectId=c-zlzc6%3Ap-hx7jt&resourceName=swagger-backend');
  }

  constructor(private client: HttpClient) {

  }
}
