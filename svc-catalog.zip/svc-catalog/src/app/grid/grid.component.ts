import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator, PageEvent, MatPaginatorIntl } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { InventoryService } from '../inventory.service';
import { HttpClient } from '@angular/common/http';
import { Cluster } from '../models/Cluster';
import { map } from 'rxjs/operators';
import {FormControl, FormGroup, Validators} from "@angular/forms";
import { MicroServiceInfo } from '../models/service';
import * as XLSX from 'xlsx'; 

@Component({
  selector: 'app-grid',
  templateUrl: './grid.component.html',
  styleUrls: ['./grid.component.css']
})
export class GridComponent implements OnInit {

  displayedColumns: string[] = ['project', 'namespace', 'servicename', 'url', 'swagger', 'description'];
  dataSource: MatTableDataSource<MicroServiceInfo>;
  clusters: Cluster[];
  // clusters: any;
  microServices: MicroServiceInfo[];
  clusterSelected: any;
  loader = true;
  searchedValue = '';
  fileName= 'ExcelSheet.xlsx';
  noOfPages: number;
  pages = [];
  noOfItems: number;
  itemsPerPageLabel = 'Page Size';
  currentPage: number;
  hasPreviousPage:boolean;
  hasNextPage:boolean;
  searchOpen = true;
  isDetails = false;
  details: Object;
  objectKeys = Object.keys;
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort: MatSort;

  constructor( private InvtServ: InventoryService, private http: HttpClient) { 
    this.InvtServ.closeDetails.subscribe(() => {
      this.isDetails = false;
    });
    this.InvtServ.openDetails.subscribe(() => {
      this.isDetails = false;
    });    
  }

  ngOnInit() {
    this.http.get(`https://ms-dev.windstream.com/tools-dev/svc-catalog/k8s/clusters`)
              .pipe(
                map(responseData => {
                  console.log(responseData);
                })
              )
              .subscribe(responseData => {

                console.log(responseData);

              });
    this.InvtServ.GetClusters().subscribe(data => {
      console.log(data);      
      this.clusters = data.clusters;
      console.log(this.clusters);
      console.log(this.clusters[0].id);
      this.clusterSelected = this.clusters[0].id;
      this.onChange(this.clusterSelected);      
    });    
    this.InvtServ.GetDetails().subscribe(data => {
      console.log(data);    
      this.InvtServ.details = data.deployment.details;
      console.log(this.objectKeys(data.deployment.details));
      this.InvtServ.isDetails = true;
      console.log(this.isDetails);
      console.log(this.InvtServ.isDetails);              
      this.InvtServ.openDetails.emit();   
    });        
    // https://ms-dev.windstream.com/playground-dev/svc-catalog/ui/projects/${this.clusterSelected}    
    
  }

  

  exportexcel(): void 
    {
       /* table id is passed over here */   
       let element = document.getElementById('excel-table'); 
       const ws: XLSX.WorkSheet =XLSX.utils.json_to_sheet(this.microServices);
      console.log(ws);
       /* generate workbook and add the worksheet */
       const wb: XLSX.WorkBook = XLSX.utils.book_new();
       XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');

       /* save to file */
       XLSX.writeFile(wb, this.fileName);
			
    }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
    if (this.dataSource.paginator && (filterValue !== '')) {
      this.dataSource.paginator.firstPage();
    }
    setTimeout(() => {
      this.paginatorChanged();
     }, 50);
  }
  clearFilter() {
    this.dataSource.filter = '';
    this.searchedValue = '';
    setTimeout(() => {
      this.paginatorChanged();
     }, 50);
  }

  onChange(id) {
    this.loader = true;    
    this.InvtServ.GetProjectss(id).subscribe(projects => {
      console.log(projects);
      this.microServices = [];
      // Assign the data to the data source for the table to render
      projects.projects.forEach(p => {
        if (p.namespaces) {
          p.namespaces.forEach(ns => {
            if (ns.ingresses) {
              ns.ingresses.forEach(ig => {
                console.log(ig);
                if (ig.publicEndpoints) {
                  ig.publicEndpoints.forEach(ep => {
                    const s: MicroServiceInfo = {                      
                      description: ig.annotations.description,
                      namespace: ns.name,
                      project: p.name,
                      servicename: ig.name,
                      swagger: (ig.labels) ? (ig.labels.swagger) ? ig.labels.swagger.toString() : '' : '',
                      url: ep.link
                    };
                    this.microServices.push(s);
                  });
                }
              });
            }
          });
        }
      });
    
      setTimeout(() => {
        console.log(this.microServices);
        this.dataSource = new MatTableDataSource(this.microServices);
        this.dataSource.paginator = this.paginator;
        this.clearFilter();
        this.loader = false;
        this.dataSource.sort = this.sort;
       this.paginatorChanged();
       console.log(this.microServices);
      }, 100);
    });
  }
  gotoFirst() {
    this.dataSource.paginator.firstPage();
  }
  gotoPrev() {
    this.dataSource.paginator.previousPage();
  }
  gotoNext() {
    this.dataSource.paginator.nextPage();
  }
  gotoLast() {
    this.dataSource.paginator.lastPage();
  }
  pageEvent(event) {
    this.paginatorChanged();
  }
  gotoPage(destination) {
    this.dataSource.paginator.pageIndex = destination;
    this.dataSource.paginator.page.next({
      pageIndex: this.dataSource.paginator.pageIndex,
      pageSize: this.dataSource.paginator.pageSize,
      length: this.dataSource.paginator.length
    });
  }
  paginatorChanged(){
    this.hasPreviousPage = this.dataSource.paginator.hasPreviousPage();
    this.hasNextPage =  this.dataSource.paginator.hasNextPage();
    this.currentPage  = this.dataSource.paginator.pageIndex;
    this.noOfItems = this.dataSource.paginator.length;
    this.noOfPages = this.dataSource.paginator.getNumberOfPages();
    this.pages = Array(this.noOfPages).fill(this.noOfPages);
  }

}


